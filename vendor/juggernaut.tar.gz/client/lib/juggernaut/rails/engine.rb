module Juggernaut
  begin
    class Engine < ::Rails::Engine
    end
  rescue NameError
  end
end
